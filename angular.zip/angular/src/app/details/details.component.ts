import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-details',
  standalone: true,
  imports: [],
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent {
  @Input() dayDetail: any;
  @Input() city: string = '';
  @Input() state: string = '';
  @Output() backToList = new EventEmitter<void>();

  onBackClick(): void {
    this.backToList.emit();
  }

  composeTweet(): void {
    const tweetContent = `The temperature in ${this.city}, ${this.state} on ${this.dayDetail.date} is ${this.dayDetail.tempHigh}°F and the conditions are ${this.dayDetail.status} #CSCI571WeatherForecast`;
    const encodedTweet = encodeURIComponent(tweetContent);
    const tweetUrl = `https://twitter.com/intent/tweet?text=${encodedTweet}`;
    window.open(tweetUrl, '_blank');
  }

}
