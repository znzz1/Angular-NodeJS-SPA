import { Component, Input, AfterViewInit, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart } from 'angular-highcharts';
import { ChartModule } from 'angular-highcharts';

import * as Highcharts from 'highcharts';
import Accessibility from 'highcharts/modules/accessibility';
Accessibility(Highcharts);
import more from 'highcharts/highcharts-more';
more(Highcharts); 
import Windbarb from 'highcharts/modules/windbarb';
Windbarb(Highcharts);

@Component({
  selector: 'app-charts',
  standalone: true,
  imports: [CommonModule, ChartModule],
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements AfterViewInit{
  @Input() weatherData: any;
  @Output() rowClick = new EventEmitter<any>();
  dayViewData: any[] = [];
  dailyTempChart: Chart | undefined;
  meteogramChart: Chart | undefined;

  @Input() lastViewedDay: any | null = null;
  @Input() isFavorite: boolean = false;
  @Output() addFavoriteEvent = new EventEmitter<any>();
  @Output() removeFavoriteEvent = new EventEmitter<any>();

  isButtonDisabled = false;
  
  ngOnInit(): void {
    this.updateDayViewData();
    this.renderCharts();
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    if(changes['weatherData']) {
      this.updateDayViewData();
      this.renderCharts();
    }
  }

  ngAfterViewInit(): void {
    this.renderCharts();
  }

  updateDayViewData(): void {
    if(this.weatherData) {
      const dailyTimeline = this.weatherData.data.timelines.find((timeline: any) => timeline.timestep === '1d');
      this.dayViewData = dailyTimeline.intervals.map((interval: any) => ({
        date: new Date(interval.startTime).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' }).replace(/(\b\w{3})\b/, '$1.'),
        status: this.getWeatherStatus(interval.values.weatherCode),
        icon: '/icon/' + this.getWeatherIcon(interval.values.weatherCode),
        tempHigh: interval.values.temperatureMax,
        tempLow: interval.values.temperatureMin,
        tempApp: interval.values.temperature,
        windSpeed: interval.values.windSpeed,
        cloudCover: interval.values.cloudCover,
        sunRise: this.formatTime(interval.values.sunriseTime),
        sunSet: this.formatTime(interval.values.sunsetTime),
        visibility: interval.values.visibility,
        humidity: interval.values.humidity,
      }));
    }
  }

  formatTime(isoTime: string): string {
    const date = new Date(isoTime);
    let hours = date.getUTCHours();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours} ${ampm}`;
  }

  renderCharts(): void {
    this.makeDailyTempChart();
    this.makeMeteogramChart();
  }

  makeDailyTempChart(): void {
    this.dailyTempChart = new Chart({
      chart: {
        type: 'arearange'
      },
      title: {
        text: 'Temperature Ranges (Min, Max)'
      },
      xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { day: '%e %b' }
      },
      yAxis: {
        title: {
          text: null
        },
        labels: {
          y: 5
        }
      },
      tooltip: {
        shared: true,
        useHTML: true,
        formatter: function () {
          const minTemp: string = (this.points?.[0].point.low as number).toFixed(2);
          const maxTemp: string = (this.points?.[0].point.high as number).toFixed(2);
          const date: string = Highcharts.dateFormat('%A, %b %e', this.x as number);

          const dotStyle = `
            display: inline-block;
            width: 0.5rem;
            height: 0.5rem;
            border-radius: 50%;
            background-color: rgb(44, 175, 254);
            margin-right: 0.3rem;
          `;
          return `<span style="font-size: 0.6rem;">${date}</span><br><span style="${dotStyle}"></span>Temperatures: <b>${minTemp}°F - ${maxTemp}°F</b>`;
        }
      },
      plotOptions: {
        arearange: {
          marker: {
              enabled: true,
              radius: 4,
              fillColor: 'rgb(44, 175, 254)',
              lineWidth: 0,
              states: {
                  hover: {
                      enabled: true,
                      radius: 6,
                      lineWidth: 1,
                      lineColor: 'white',
                      fillColor: 'rgb(44, 175, 254)'
                  }
              }
          },
          states: { 
              hover: {
                  halo: {
                      size: 10,
                      attributes: {
                          fill: 'rgb(44, 175, 254)'
                      }
                  }
              }
          },
        }
      },
      series: [
        {
          type: 'arearange',
          name: 'Temperature Range',
          showInLegend: false,
          data: this.dayViewData.map(day => [
            new Date(day.date).getTime(),
            day.tempLow,
            day.tempHigh
          ]),
          color: {
            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
            stops: [
                [0, 'rgba(255, 140, 0, 0.9)'],
                [1, 'rgba(30, 144, 255, 0.9)']
            ]
          },
          lineColor: 'blue',
        }
      ]
    });
  }
  
  makeMeteogramChart(): void {
    const intervals = this.weatherData.data.timelines[1].intervals;
    const temperature = intervals.map((interval: any) => [new Date(interval.startTime).getTime(), interval.values.temperature]);
    const humidity = intervals.map((interval: any) => [new Date(interval.startTime).getTime(), interval.values.humidity]);
    const pressure = intervals.map((interval: any) => [new Date(interval.startTime).getTime(), interval.values.pressureSeaLevel]);
    const windSpeed = intervals.map((interval: any) => [new Date(interval.startTime).getTime(), interval.values.windSpeed]);

    const windSpeedDirection = intervals.map((interval: { startTime: string; values: { windSpeed: number; windDirection: number } }) => ({
      x: new Date(interval.startTime).getTime(),
      value: interval.values.windSpeed,
      direction: interval.values.windDirection
    }));

    const firstTimestamp = temperature[0][0]; const lastTimestamp = temperature[temperature.length - 1][0];

    this.meteogramChart = new Chart({
      chart: {
        type: 'spline',
        scrollablePlotArea: {
          minWidth: 750,
          scrollPositionX: 0,
        },
      },
      title: {
        text: 'Hourly Weather (For Next 5 Days)'
      },
      xAxis: [
      {
        tickLength: 0,
        type: 'datetime',
        tickInterval: 6 * 3600 * 1000,
        minorTickInterval: 3600 * 1000,
        labels: {
            format: '{value:%H}',
            style: {
                textOverflow: 'ellipsis'
            }
        },
        gridLineWidth: 1,
        minorGridLineWidth: 0.9,
        min: firstTimestamp,
        max: lastTimestamp,
        plotLines: [
            {
                color: 'rgb(207, 207, 207)',
                width: 2,
                value: firstTimestamp,
                zIndex: 5
            },
            {
                color: 'rgb(207, 207, 207)',
                width: 2,
                value: lastTimestamp + 1 * 3600 * 1000,
                zIndex: 5
            }
        ]
      },
      {
        linkedTo: 0,
        type: 'datetime',
        tickInterval: 24 * 3600 * 1000,
        labels: {
            format: '{value:<b>%a</b> %b %e}',
            align: 'left',
            x: 2,
            y: 0,
            style: {
                textOverflow: 'ellipsis',
            }
        },
        opposite: true,
        tickLength: 15,
        gridLineWidth: 1,
      }
      ],
      yAxis: [
      {
        title: {
            text: null
        },
        labels: {
            format: '{value}°',
            style: {
                fontSize: '0.8rem',
            },
            x: -2, 
        },
        min: 0,
        max: 105,
        tickInterval: 15,
        gridLineWidth: 1,
        height: '90%' ,
      },
      {
        title: {
            text: null
        },    
        labels: {
            enabled: false
        },
        min: 0,
        max: 130,
        tickInterval: 10,
        gridLineWidth: 0,
        height: '90%',
      },
      {
        title: {
            text: 'inHg',
            rotation: 0,
            align:'high',
            style: {
                fontSize: '0.8rem',
                color : 'rgb(255,175,54)',
            },
            x : -20,
        },
        labels: {
            formatter: function () {
                if (this.value === 30) {
                    return this.value.toString();
                }
                return '';
            },
            style: {
                fontSize: '0.6rem',
                color : 'rgb(255,175,54)',
            },
            x: 4,
        },
        min: 0,
        max: 60,
        tickPositions: [0, 30, 60],
        opposite: true,
        gridLineWidth: 1,
        tickLength: 2,
        height: '90%',
      },
      {
        title: {
            text: null,
        },
        labels: {
            enabled: false
        },
        min: 0,
        max: 360,
        tickInterval: 45,
        gridLineWidth: 0,
        top: '91%',
        height: '10%',
      },
      ],
      tooltip: {
        shared: true,
        useHTML: true,
        formatter: function () {
          const date: string = Highcharts.dateFormat('%A, %b %e, %H:%M', this.x as number);
          const temp: string = this.points?.[0]?.y !== undefined && this.points?.[0]?.y !== null? this.points[0].y.toFixed(2): 'N/A';
          const hum: string = this.points?.[1]?.y !== undefined && this.points?.[1]?.y !== null? this.points[1].y.toFixed(0): 'N/A';
          const pressure: string = this.points?.[2]?.y !== undefined && this.points?.[2]?.y !== null? this.points[2].y.toFixed(0): 'N/A';
          
          const wind = windSpeed.find((interval: [number, number]) => interval[0] === this.x);
          const windValue: string = wind ? wind[1].toFixed(2) : 'N/A';
          
          
            let windDescription = '';
            if (windValue !== 'N/A') {
                const windSpeedValue = parseFloat(windValue);
                if (windSpeedValue < 1) {
                    windDescription = '(Calm)';
                } else if (windSpeedValue <= 3) {
                    windDescription = '(Light air)';
                } else if (windSpeedValue <= 7) {
                    windDescription = '(Light breeze)';
                } else if (windSpeedValue <= 12) {
                    windDescription = '(Gentle breeze)';
                } else if (windSpeedValue <= 18) {
                    windDescription = '(Moderate breeze)';
                } else if (windSpeedValue <= 24) {
                    windDescription = '(Fresh breeze)';
                } else if (windSpeedValue <= 31) {
                    windDescription = '(Strong breeze)';
                } else if (windSpeedValue <= 38) {
                    windDescription = '(Near gale)';
                } else if (windSpeedValue <= 46) {
                    windDescription = '(Gale)';
                } else if (windSpeedValue <= 54) {
                    windDescription = '(Strong gale)';
                } else if (windSpeedValue <= 63) {
                    windDescription = '(Storm)';
                } else if (windSpeedValue <= 75) {
                    windDescription = '(Violent storm)';
                } else {
                    windDescription = '(Hurricane)';
                }
            }
        
        return `<span style="font-size: 0.6rem;">${date}</span><br>
                <span style="color: red;">●</span> Temperature: <b>${temp}°F</b><br>
                <span style="color: blue;">●</span> Humidity: <b>${hum} %</b><br>
                <span style="color: rgb(255,175,54);">●</span> Air Pressure: <b>${pressure} inHg</b><br>
                <span style="color: green;">●</span> Wind Speed: <b>${windValue} mph</b> ${windDescription}`;
        }
      },
      plotOptions:{

      },
      series: [
      {
        name: 'Temperature',
        data: temperature,
        type: 'spline',
        color: 'red',
        lineWidth: 2,
        zIndex: 10,
        marker: {
          enabled: false,
          radius: 5,
          fillColor: 'red',
          lineWidth: 1,
          lineColor: 'white',
          states: {
            hover: {
              enabled: true,
              radius: 1
            }
          }
        }
      },
      {
        name: 'Humidity',
        data: humidity.map((interval: [number, number]) => [
          new Date(interval[0]).getTime(),
          interval[1]
        ]),
        type: 'column',
        color: 'rgb(123,198,254)',
        yAxis: 1,
        zIndex: 9,
        pointRange: 3600 * 1000,
        pointPlacement: 'between',
        groupPadding: 0,
        pointPadding: 0,
        borderRadius: 3,
        dataLabels: {
          enabled: true,
          formatter: function () {
              return Math.round(this.y ?? 0).toString();
          },
          style: {
              fontSize: '7px',
              fontWeight: 'bold',
              textOutline: '1px contrast',
              color: 'rgb(127,127,127)',
          },
          align: 'center',
          verticalAlign: 'bottom',
          inside: false,
          crop: false,
          overflow: 'allow'
        },
        states: {
          hover: {
              enabled: true
          }
        }
      },
      {
        name: 'Air Pressure',
        data: pressure.map((interval: [number, number]) => [
          new Date(interval[0]).getTime(),
          interval[1]
        ]),
        type: 'spline',
        dashStyle: 'ShortDot',
        color: 'rgb(255,175,54)',
        yAxis: 2,
        zIndex: 10,
        marker: {
          enabled: true,
          symbol: 'diamond',
          radius: 1,
          fillColor: 'rgb(255,175,54)',
          lineWidth: 0,
          states: {
            hover: {
              enabled: true,
              radius: 5,
              fillColor: 'rgb(255,175,54)',
              lineWidth: 1,
              lineColor: 'white'
            }
          }
        }
      },
      {
        name: 'Wind',
        type: 'windbarb',
        data: windSpeedDirection.filter((interval: { startTime: string; values: { windSpeed: number; windDirection: number } }, index: number) => index % 2 === 0),
        yAxis: 3,
        color: 'purple',
        vectorLength: 5,
        pointPlacement: 'between',
      }
      ],
      legend: {
        enabled: false
    },
    });
  }

  getWeatherStatus(weatherCode: number): string {
    return this.weatherCodeMapping[weatherCode];
  }

  getWeatherIcon(weatherCode: number): string {
    return this.weatherIconMapping[weatherCode];
  }
  
  weatherCodeMapping: { [key: number]: string } = {
    1000: "Clear",
    1100: "Mostly Clear",
    1101: "Partly Cloudy",
    1102: "Mostly Cloudy",
    1001: "Cloudy",
    2000: "Fog",
    2100: "Light Fog",
    4000: "Drizzle",
    4001: "Rain",
    4200: "Light Rain",
    4201: "Heavy Rain",
    5000: "Snow",
    5001: "Flurries",
    5100: "Light Snow",
    5101: "Heavy Snow",
    6000: "Freezing Drizzle",
    6001: "Freezing Rain",
    6200: "Light Freezing Rain",
    6201: "Heavy Freezing Rain",
    7000: "Ice Pellets",
    7101: "Heavy Ice Pellets",
    7102: "Light Ice Pellets",
    8000: "Thunderstorm"
  };

  weatherIconMapping: { [key: number]: string } = {
    1000: "clear_day.svg",
    1100: "mostly_clear_day.svg",
    1101: "partly_cloudy_day.svg",
    1102: "mostly_cloudy.svg",
    1001: "cloudy.svg",
    2000: "fog.svg",
    2100: "fog_light.svg",
    4000: "drizzle.svg",
    4001: "rain.svg",
    4200: "rain_light.svg",
    4201: "rain_heavy.svg",
    5000: "snow.svg",
    5001: "flurries.svg",
    5100: "snow_light.svg",        
    5101: "snow_heavy.svg",        
    6000: "freezing_drizzle.svg",  
    6001: "freezing_rain.svg",     
    6200: "freezing_rain_light.svg",
    6201: "freezing_rain_heavy.svg",
    7000: "ice_pellets.svg",       
    7101: "ice_pellets_heavy.svg",        
    7102: "ice_pellets_light.svg",        
    8000: "tstorm.svg"
  };

  onRowClick(dayDetail: any): void {
    this.lastViewedDay = dayDetail;
    this.rowClick.emit(dayDetail);
  }

  sendRecentData(): void {
    const dayToView = this.lastViewedDay || this.dayViewData[0];
    this.rowClick.emit(dayToView);
  }

  toggleFavorite(): void {
    if (this.isButtonDisabled) return;
    this.isButtonDisabled = true;
    if (this.isFavorite) {
      this.removeFavoriteEvent.emit();
    } else {
      this.addFavoriteEvent.emit();
    }
    this.isFavorite = !this.isFavorite;

    setTimeout(() => {
      this.isButtonDisabled = false;
    }, 500);
  }
}