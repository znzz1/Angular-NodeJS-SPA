import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { debounceTime, switchMap, map, catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { CommonModule } from '@angular/common';
import { ChartsComponent } from "./charts/charts.component";
import { DetailsComponent } from './details/details.component';
import { MapComponent } from './map/map.component';
import { FavoriteComponent } from './favorite/favorite.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { trigger, transition, style, animate, group, query } from '@angular/animations';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, ChartsComponent, DetailsComponent, BrowserAnimationsModule, MapComponent, FavoriteComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('slideTransition', [
      transition('main => detail', [
        style({ transform: 'translateX(100%)' }),
        animate('100ms ease-out', style({ transform: 'translateX(0)' }))
      ]),
      transition('detail => main', [
        animate('100ms ease-out', style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class AppComponent {
  weatherForm: FormGroup;
  suggestions: string[] = [];
  isSearchDisabled = true;
  data: any;
  title: string = '';
  selectedDayDetail: any = null;
  viewState: 'main' | 'detail' = 'main';
  xInfo: string[] = ['', ''];

  favorites: any[] = [];
  lastId: string | null = null;

  errorMessage: string | null = null;

  isLoading: boolean = false;

  onRowClick(dayDetail: any): void {
    this.selectedDayDetail = dayDetail;
    this.viewState = 'detail';
  }

  onBackToList(): void {
    this.viewState = 'main';
  }

  get latitude(): number | null {
    const lat = this.data?.location?.latitude;
    return lat !== undefined ? parseFloat(lat) : null;
  }

  get longitude(): number | null {
    const lng = this.data?.location?.longitude;
    return lng !== undefined ? parseFloat(lng) : null;
  }

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.weatherForm = this.fb.group({
      street: ['', [this.myValidator]],
      city: ['', [this.myValidator]],
      state: ['',[Validators.required]],
      auto: [false]
    });

    this.weatherForm.statusChanges.subscribe(() => {
      this.updateSearchButtonState();
    });
  }

  ngOnInit(): void {
    this.onAutoChange();
    this.onCityInput();
  }

  updateSearchButtonState(): void {
    const isAutoChecked = this.weatherForm.get('auto')?.value;
    const areFieldsValid = this.weatherForm.get('street')?.valid && 
                           this.weatherForm.get('city')?.valid && 
                           this.weatherForm.get('state')?.valid;

    this.isSearchDisabled = !(isAutoChecked || areFieldsValid);
  }

  myValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const isEmptyOrWhitespace = (control.value || '').trim().length === 0;
    return !isEmptyOrWhitespace ? null : { invalid: true };
  }

  onAutoChange(): void {
    this.weatherForm.get('auto')?.valueChanges.subscribe((isCurrentLocation) => {
      if (isCurrentLocation) {
        this.weatherForm.get('street')?.disable({ emitEvent: false });
        this.weatherForm.get('city')?.disable({ emitEvent: false });
        this.weatherForm.get('state')?.disable({ emitEvent: false });
      } else {
        this.weatherForm.get('street')?.enable({ emitEvent: false });
        this.weatherForm.get('city')?.enable({ emitEvent: false });
        this.weatherForm.get('state')?.enable({ emitEvent: false });
      }
    });
  }
  
  clearForm(): void {
    this.weatherForm.reset({
      street: '',
      city: '',
      state: '',
      auto: false
    });
    this.updateSearchButtonState();
    this.title = '';
    this.data = null;
    this.errorMessage = null;
  }

  onCityInput(): void {
    this.weatherForm.get('city')?.valueChanges.pipe(
      debounceTime(100),
      switchMap((input: string) => this.fetchCitySuggestions(input))
    ).subscribe((suggestions: string[]) => {
      this.suggestions = suggestions;
    });
  }
  
  fetchCitySuggestions(input: string): Observable<string[]> {
    if (!input) return of([]);
    const url = `/api/autocomplete?input=${input}`;
    return this.http.get<any>(url).pipe(
      map(response => {
        if (response && Array.isArray(response.predictions)) {
          return response.predictions.map((prediction: any) => {
            const cityName = prediction.description.split(',')[0];
            return cityName;
          });
        }
        return [];
      }),
      catchError(() => of([]))
    );
  }
  
  selectSuggestion(suggestion: string): void {
    this.weatherForm.get('city')?.setValue(suggestion, { emitEvent: false });
    this.suggestions = [];
  }

  onSubmit(): void {
    this.selectedDayDetail = null;
    this.isLoading = true;
    if(this.weatherForm.get('auto')?.value) {
      this.fetchWeatherUsingIPInfo();
    } else {
      this.fetchWeatherUsingAddress();
    }
    this.selectResults();
  }

  fetchWeatherUsingIPInfo(): void {
    this.errorMessage = null;
    this.http.get(`https://ipinfo.io/json?token=31d2031fe8aff2`).subscribe({
      next: (response: any) => {
        const loc = response.loc;
        const [latitude, longitude] = loc.split(',');
        this.http.post('/api/weather/auto', { latitude, longitude }).subscribe({
          next: (data) => {
            this.updateTitle(response.city, response.region);
            this.data = data;
            this.lastId = null;
            this.isLoading = false;
          },
          error: (error) => {
            console.error(error);
            this.errorMessage = 'An error occured please try again later';
            this.title = '';
            this.isLoading = false;
          },
        });
      },
      error: (error) => {
        console.error(error);
        this.errorMessage = 'An error occured please try again later';
        this.title = '';
        this.isLoading = false;
      }
    });
  }

  fetchWeatherUsingAddress(): void {
    this.errorMessage = null;
    const { street, city, state } = this.weatherForm.value;
    this.http.post('/api/weather', { street, city, state }).subscribe({
      next: (data) => {
        this.updateTitle(city, state);
        this.data = data;
        this.lastId = null;
        this.isLoading = false;
      },
      error: (error) => {
        console.error(error);
        this.errorMessage = 'An error occured please try again later';
        this.title = '';
        this.isLoading = false;
      },
    });
  }

  updateTitle(city: string, stateOrRegion: string): void {
    this.xInfo = [city, stateOrRegion];
    this.title = `Forecast at ${city}, ${stateOrRegion}`;
  }

  isResultsSelected = true;
  isFavoritesSelected = false;

  selectResults() {
    this.isResultsSelected = true;
    this.isFavoritesSelected = false;
  }

  selectFavorites() {
    this.isResultsSelected = false;
    this.isFavoritesSelected = true;
    this.updateFavorites();
    this.errorMessage = null;
  }

  updateFavorites(): void {
    this.http.get<any[]>('/api/favorites').subscribe({
      next: (data) => {
        this.favorites = data;
      },
      error: (error) => {
        console.error('Failed to fetch favorites:', error);
      }
    });
  }

  addFavorite(): void {
    const favoriteData = {
      city: this.xInfo[0],
      state: this.xInfo[1],
      data: this.data
    };
  
    this.http.post<any>('/api/favorites', favoriteData).subscribe({
      next: (savedFavorite) => {
        console.log('Favorite added successfully');
        this.lastId = savedFavorite._id;
        this.updateFavorites();
      },
      error: (error) => {
        console.error('Failed to add favorite:', error);
      }
    });
  }
  
  removeFavorite(): void {
    this.http.delete(`/api/favorites/${this.lastId}`).subscribe({
      next: () => {
        console.log('Favorite removed successfully');
        this.lastId = null;
        this.updateFavorites();
      },
      error: (error) => {
        console.error('Failed to remove favorite:', error);
      }
    });
  }
  
  isRecordFavorite(): boolean {
    return this.favorites.some(favorite => favorite._id === this.lastId);
  }

  removeFavoriteById(favoriteId: string): void {
    this.http.delete(`/api/favorites/${favoriteId}`).subscribe({
      next: () => {
        console.log('Favorite removed successfully');
        this.favorites = this.favorites.filter(fav => fav._id !== favoriteId);
      },
      error: (error) => {
        console.error('Failed to remove favorite:', error);
      }
    });
  }

  loadFavoriteData(favorite: any): void {
    this.selectedDayDetail = null;
    this.isLoading = true;
    this.data = favorite.data;
    this.xInfo = [favorite.city, favorite.state];
    this.updateTitle(favorite.city, favorite.state);
    this.lastId = favorite._id;
    this.errorMessage = null;

    this.selectResults();

    setTimeout(() => {
      this.isLoading = false;
    }, 200);
  }
}
