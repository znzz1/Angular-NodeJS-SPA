import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-favorite',
  standalone: true,
  imports: [ CommonModule ],
  templateUrl: './favorite.component.html',
  styleUrl: './favorite.component.css'
})
export class FavoriteComponent {
  @Input() favorites: any[] = [];
  @Output() removeFavorite = new EventEmitter<string>();
  @Output() loadFavorite = new EventEmitter<any>();

  onRemoveFavorite(favoriteId: string): void {
    this.removeFavorite.emit(favoriteId);
  }

  onLoadFavorite(favorite: any): void {
    this.loadFavorite.emit(favorite);
  }
}
